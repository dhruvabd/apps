@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.jjemsboys.socialscience.studyapp.ui.screens.saved

import androidx.compose.animation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.jjemsboys.socialscience.studyapp.data.BookmarkManager
import com.jjemsboys.socialscience.studyapp.data.ChapterRepository
import com.jjemsboys.socialscience.studyapp.ui.components.EmptyState
import com.jjemsboys.socialscience.studyapp.ui.components.ExpandableQACard
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SavedScreen(nav: NavController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val bookmarkManager = remember { BookmarkManager(context) }
    val savedIds by bookmarkManager.savedQa.collectAsState(initial = emptySet())
    val allQA = remember { ChapterRepository.getAllQA() }
    val savedQA = allQA.filter { savedIds.contains(it.id) }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Text("Saved", fontWeight = FontWeight.Bold)
                },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, null)
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .padding(padding)
                .padding(horizontal = 16.dp)
                .padding(bottom = 104.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(8.dp))
            }

            if (savedQA.isEmpty()) {
                item {
                    EmptyState(
                        icon = Icons.Default.BookmarkBorder,
                        title = "No saved items",
                        message = "Tap the bookmark icon on any question to save it here for quick review",
                        modifier = Modifier.padding(top = 60.dp)
                    )
                }
            } else {
                item {
                    Text(
                        text = "${savedQA.size} saved item${if (savedQA.size != 1) "s" else ""}",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(bottom = 4.dp)
                    )
                }

                itemsIndexed(savedQA) { _, qa ->
                    AnimatedVisibility(
                        visible = true,
                        enter = fadeIn() + slideInVertically { it / 2 }
                    ) {
                        ExpandableQACard(
                            qa = qa,
                            isSaved = true,
                            onToggleSave = { scope.launch { bookmarkManager.toggleSaveQA(qa.id) } }
                        )
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}
