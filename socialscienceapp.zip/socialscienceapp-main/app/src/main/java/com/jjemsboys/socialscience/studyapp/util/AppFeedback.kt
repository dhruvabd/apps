package com.jjemsboys.socialscience.studyapp.util

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import android.view.HapticFeedbackConstants
import android.view.View
import com.jjemsboys.socialscience.studyapp.R

object AppFeedback {
    @Volatile
    var hapticsEnabled: Boolean = true

    @Volatile
    var soundEffectsEnabled: Boolean = true

    private var soundPool: SoundPool? = null
    private var clickSoundId: Int = 0
    private var soundLoaded: Boolean = false
    private var isInitialized: Boolean = false

    fun init(context: Context) {
        if (isInitialized) return

        val appContext = context.applicationContext
        soundPool = SoundPool.Builder()
            .setMaxStreams(2)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .build().also { pool ->
                pool.setOnLoadCompleteListener { _, sampleId, status ->
                    if (status == 0 && sampleId == clickSoundId) {
                        soundLoaded = true
                    }
                }
            }

        clickSoundId = soundPool?.load(appContext, R.raw.click, 1) ?: 0
        isInitialized = true
    }

    fun sync(hapticsEnabled: Boolean, soundEffectsEnabled: Boolean) {
        this.hapticsEnabled = hapticsEnabled
        this.soundEffectsEnabled = soundEffectsEnabled
    }

    fun interact(view: View, feedbackConstant: Int = HapticFeedbackConstants.CONFIRM) {
        if (hapticsEnabled) {
            view.performHapticFeedback(feedbackConstant)
        }
        if (soundEffectsEnabled && soundLoaded && clickSoundId != 0) {
            soundPool?.play(clickSoundId, 1f, 1f, 1, 0, 1f)
        }
    }
}
