package com.jjemsboys.socialscience.studyapp
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.jjemsboys.socialscience.studyapp.data.BookmarkManager
import com.jjemsboys.socialscience.studyapp.ui.components.AppFeedbackState
import com.jjemsboys.socialscience.studyapp.ui.components.FeedbackManager
import com.jjemsboys.socialscience.studyapp.ui.components.LocalAppFeedback
import com.jjemsboys.socialscience.studyapp.ui.navigation.PremiumBottomBar
import com.jjemsboys.socialscience.studyapp.ui.screens.chapters.ChapterDetailScreen
import com.jjemsboys.socialscience.studyapp.ui.screens.chapters.ChaptersScreen
import com.jjemsboys.socialscience.studyapp.ui.screens.flashcard.FlashcardScreen
import com.jjemsboys.socialscience.studyapp.ui.screens.flashcard.FlashcardSelectorScreen
import com.jjemsboys.socialscience.studyapp.ui.screens.home.HomeScreen
import com.jjemsboys.socialscience.studyapp.ui.screens.quiz.QuizScreen
import com.jjemsboys.socialscience.studyapp.ui.screens.quiz.QuizSelectorScreen
import com.jjemsboys.socialscience.studyapp.ui.screens.saved.SavedScreen
import com.jjemsboys.socialscience.studyapp.ui.screens.search.SearchScreen
import com.jjemsboys.socialscience.studyapp.ui.screens.settings.AboutScreen
import com.jjemsboys.socialscience.studyapp.ui.screens.settings.SettingsScreen
import com.jjemsboys.socialscience.studyapp.ui.theme.SocialScienceTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val context = LocalContext.current
            val bookmarkManager = remember { BookmarkManager(context) }
            val feedbackManager = remember { FeedbackManager(context) }
            val systemDark = isSystemInDarkTheme()
            val isDarkModeSetting by bookmarkManager.isDarkMode.collectAsState(initial = null)
            val hapticEnabled by feedbackManager.hapticEnabled.collectAsState(initial = false)
            val soundEnabled by feedbackManager.soundEnabled.collectAsState(initial = false)
            val finalDarkMode = isDarkModeSetting ?: systemDark

            CompositionLocalProvider(
                LocalAppFeedback provides AppFeedbackState(
                    hapticEnabled = hapticEnabled,
                    soundEnabled = soundEnabled
                )
            ) {
                SocialScienceTheme(darkTheme = finalDarkMode) {
                    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                        AppNavHost()
                    }
                }
            }
        }
    }
}

@Composable
fun AppNavHost() {
    val navController = rememberNavController()
    val currentBackStack by navController.currentBackStackEntryAsState()
    val currentRoute = currentBackStack?.destination?.route

    val showBottomBar = currentRoute in listOf("home", "chapters", "search", "saved", "settings")

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            androidx.compose.animation.AnimatedVisibility(
                visible = showBottomBar,
                enter = fadeIn() + androidx.compose.animation.slideInVertically { it },
                exit = fadeOut() + androidx.compose.animation.slideOutVertically { it }
            ) {
                PremiumBottomBar(navController, currentRoute)
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = "home",
            modifier = Modifier.padding(padding),
            enterTransition = {
                fadeIn(tween(300)) + slideIntoContainer(AnimatedContentTransitionScope.SlideDirection.Start, tween(300))
            },
            exitTransition = {
                fadeOut(tween(300)) + slideOutOfContainer(AnimatedContentTransitionScope.SlideDirection.End, tween(300))
            },
            popEnterTransition = {
                fadeIn(tween(300)) + slideIntoContainer(AnimatedContentTransitionScope.SlideDirection.End, tween(300))
            },
            popExitTransition = {
                fadeOut(tween(300)) + slideOutOfContainer(AnimatedContentTransitionScope.SlideDirection.Start, tween(300))
            }
        ) {
            composable("home") { HomeScreen(navController) }
            composable("chapters") { ChaptersScreen(navController) }
            composable("chapter/{id}") { backStack ->
                ChapterDetailScreen(
                    navController,
                    backStack.arguments?.getString("id") ?: ""
                )
            }
            composable("search") { SearchScreen(navController) }
            composable("saved") { SavedScreen(navController) }
            composable("quiz") { 
                QuizSelectorScreen(navController, mode = "quiz")
            }
            composable("test") { 
                QuizSelectorScreen(navController, mode = "test")
            }
            composable("quiz_play/{id}/{mode}") { backStack ->
                QuizScreen(
                    navController,
                    backStack.arguments?.getString("id") ?: "",
                    backStack.arguments?.getString("mode") ?: "quiz"
                )
            }
            composable("flashcard") { FlashcardSelectorScreen(navController) }
            composable("flashcard_play/{id}") { backStack ->
                FlashcardScreen(
                    navController,
                    backStack.arguments?.getString("id") ?: ""
                )
            }
            composable("settings") { SettingsScreen(navController) }
            composable("about") { AboutScreen(navController) }
        }
    }
}
