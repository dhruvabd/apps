package com.jjemsboys.socialscience.studyapp.ui.components

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import android.view.HapticFeedbackConstants
import android.view.View
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.jjemsboys.socialscience.studyapp.R

data class AppFeedbackSettings(
    val hapticEnabled: Boolean = false,
    val soundEnabled: Boolean = false
)

object AppFeedbackStateHolder {
    var settings by mutableStateOf(AppFeedbackSettings())
}

object AppSoundPlayer {
    private var soundPool: SoundPool? = null
    private var clickSoundId: Int = 0
    private var isInitialized = false

    fun init(context: Context) {
        if (isInitialized) return
        val audioAttributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        soundPool = SoundPool.Builder()
            .setMaxStreams(1)
            .setAudioAttributes(audioAttributes)
            .build()
            .also { pool ->
                clickSoundId = pool.load(context.applicationContext, R.raw.click, 1)
            }

        isInitialized = true
    }

    fun playClick() {
        val pool = soundPool ?: return
        if (clickSoundId == 0) return
        pool.play(clickSoundId, 1f, 1f, 1, 0, 1f)
    }
}

fun View.performAppFeedback(
    hapticType: Int = HapticFeedbackConstants.CONFIRM
) {
    val settings = AppFeedbackStateHolder.settings
    if (settings.hapticEnabled) {
        performHapticFeedback(hapticType)
    }
    if (settings.soundEnabled) {
        AppSoundPlayer.playClick()
    }
}
