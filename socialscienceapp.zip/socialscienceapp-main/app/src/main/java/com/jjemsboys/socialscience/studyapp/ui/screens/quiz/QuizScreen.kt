package com.jjemsboys.socialscience.studyapp.ui.screens.quiz

import android.view.HapticFeedbackConstants
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.jjemsboys.socialscience.studyapp.data.ChapterRepository
import com.jjemsboys.socialscience.studyapp.ui.components.PremiumButton
import com.jjemsboys.socialscience.studyapp.ui.components.PremiumOutlinedButton
import com.jjemsboys.socialscience.studyapp.ui.viewmodel.QuizViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuizScreen(nav: NavController, chapterId: String, mode: String) {
    val view = LocalView.current
    val viewModel: QuizViewModel = viewModel()

    LaunchedEffect(chapterId, mode) {
        viewModel.setupQuiz(chapterId, mode, ChapterRepository.chapters)
    }

    if (viewModel.questions.isEmpty()) {
        EmptyQuizState(nav)
        return
    }

    if (viewModel.isFinished) {
        QuizResultScreen(nav, viewModel)
        return
    }

    val question = viewModel.questions[viewModel.currentIndex]
    val progress = (viewModel.currentIndex + 1).toFloat() / viewModel.questions.size

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        if (mode == "test") "Test" else "Quiz",
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, null)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(horizontal = 16.dp)
                .fillMaxSize()
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            // Progress
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp)),
                color = MaterialTheme.colorScheme.primary,
                trackColor = MaterialTheme.colorScheme.surfaceVariant,
                strokeCap = StrokeCap.Round
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    "Question ${viewModel.currentIndex + 1}/${viewModel.questions.size}",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (viewModel.isTestMode) {
                    Text(
                        "${viewModel.timeLeft}s",
                        style = MaterialTheme.typography.labelLarge,
                        color = if (viewModel.timeLeft < 10) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Question Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
            ) {
                Column(modifier = Modifier.padding(24.dp)) {
                    Text(
                        text = question.q,
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Options
            question.options.forEachIndexed { idx, option ->
                val isCorrect = idx == question.answer
                val isSelected = viewModel.selectedAnswer == idx
                val bgColor = when {
                    !viewModel.answered -> MaterialTheme.colorScheme.surfaceVariant
                    isCorrect -> MaterialTheme.colorScheme.primaryContainer
                    isSelected -> MaterialTheme.colorScheme.errorContainer
                    else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                }
                val contentColor = when {
                    !viewModel.answered -> MaterialTheme.colorScheme.onSurfaceVariant
                    isCorrect -> MaterialTheme.colorScheme.onPrimaryContainer
                    isSelected -> MaterialTheme.colorScheme.onErrorContainer
                    else -> MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                }

                val interactionSource = remember { MutableInteractionSource() }
                val isPressed by interactionSource.collectIsPressedAsState()
                val scale by animateFloatAsState(if (isPressed) 0.98f else 1f, label = "opt_scale")

                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .scale(scale)
                        .padding(vertical = 6.dp),
                    shape = RoundedCornerShape(16.dp),
                    color = bgColor,
                    onClick = {
                        if (!viewModel.answered) {
                            view.performHapticFeedback(HapticFeedbackConstants.CONFIRM)
                            viewModel.submitAnswer(idx)
                        }
                    },
                    interactionSource = interactionSource
                ) {
                    Row(
                        modifier = Modifier.padding(20.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(
                                    if (viewModel.answered && isCorrect) MaterialTheme.colorScheme.primary
                                    else if (viewModel.answered && isSelected) MaterialTheme.colorScheme.error
                                    else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "${('A' + idx)}",
                                style = MaterialTheme.typography.labelLarge,
                                color = if (viewModel.answered && (isCorrect || isSelected)) Color.White
                                else MaterialTheme.colorScheme.onSurfaceVariant,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            text = option,
                            modifier = Modifier.weight(1f),
                            color = contentColor,
                            fontWeight = if (viewModel.answered && isCorrect) FontWeight.Bold else FontWeight.Normal
                        )
                        AnimatedVisibility(visible = viewModel.answered && isCorrect) {
                            Icon(Icons.Default.CheckCircle, null, tint = MaterialTheme.colorScheme.primary)
                        }
                        AnimatedVisibility(visible = viewModel.answered && isSelected && !isCorrect) {
                            Icon(Icons.Default.Cancel, null, tint = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            AnimatedVisibility(
                visible = viewModel.answered,
                enter = fadeIn() + slideInVertically { it }
            ) {
                PremiumButton(
                    onClick = { viewModel.nextQuestion() },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        if (viewModel.currentIndex == viewModel.questions.size - 1) "Finish Quiz" else "Next Question",
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
fun QuizResultScreen(nav: NavController, viewModel: QuizViewModel) {
    val result = viewModel.getResult()
    val view = LocalView.current

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(32.dp)
                .fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            val primaryColor = if (result.isPass) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error

            Box(
                modifier = Modifier
                    .size(160.dp)
                    .clip(CircleShape)
                    .background(primaryColor.copy(alpha = 0.1f)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "${result.percentage}%",
                        style = MaterialTheme.typography.displayMedium,
                        color = primaryColor,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${result.score}/${result.total}",
                        style = MaterialTheme.typography.titleLarge,
                        color = primaryColor
                    )
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            Text(
                text = if (result.isPass) "Great Job!" else "Keep Practicing",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = if (result.isPass) "You scored above 70%. Well done!" else "Review the chapters and try again to improve your score.",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )

            Spacer(modifier = Modifier.height(32.dp))

            PremiumButton(
                onClick = {
                    view.performHapticFeedback(HapticFeedbackConstants.CONFIRM)
                    nav.popBackStack()
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Done", fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(12.dp))

            PremiumOutlinedButton(
                onClick = {
                    viewModel.setupQuiz("all", "quiz", ChapterRepository.chapters)
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Retry", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun EmptyQuizState(nav: NavController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("No questions available", style = MaterialTheme.typography.headlineSmall)
        Spacer(modifier = Modifier.height(16.dp))
        PremiumButton(onClick = { nav.popBackStack() }) {
            Text("Go Back")
        }
    }
}
