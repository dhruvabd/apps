package com.jjemsboys.socialscience.studyapp.ui.navigation
import com.jjemsboys.socialscience.studyapp.ui.components.performAppFeedback
import android.view.HapticFeedbackConstants
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalView
import com.jjemsboys.socialscience.studyapp.ui.components.LocalAppFeedback
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController

private data class NavItem(
    val route: String,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
)

private val bottomNavItems = listOf(
    NavItem("home", "Home", Icons.Filled.Home, Icons.Outlined.Home),
    NavItem("chapters", "Chapters", Icons.Filled.MenuBook, Icons.Outlined.MenuBook),
    NavItem("search", "Search", Icons.Filled.Search, Icons.Outlined.Search),
    NavItem("saved", "Saved", Icons.Filled.Bookmark, Icons.Outlined.BookmarkBorder),
    NavItem("settings", "Settings", Icons.Filled.Settings, Icons.Outlined.Settings)
)

@Composable
fun PremiumBottomBar(navController: NavHostController, currentRoute: String?) {
    val view = LocalView.current
    val appFeedback = LocalAppFeedback.current

    // FIX: Wrap in Surface with proper padding for system bars
    Surface(
        modifier = Modifier
            .shadow(8.dp, RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
            .fillMaxWidth()
            .navigationBarsPadding(),  // FIX: Properly handle system gesture navigation area
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
    ) {
        NavigationBar(
            modifier = Modifier
                .height(80.dp)  // FIX: Increased height from 76 to 80
                .padding(bottom = 4.dp),  // FIX: Extra padding for gesture nav
            tonalElevation = 0.dp,
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.onSurface
        ) {
            bottomNavItems.forEach { item ->
                val selected = currentRoute == item.route
                val interactionSource = remember { MutableInteractionSource() }
                val isPressed by interactionSource.collectIsPressedAsState()
                val scale by animateFloatAsState(if (isPressed) 0.9f else 1f, label = "nav_scale")

                NavigationBarItem(
                    selected = selected,
                    onClick = {
                        if (!selected) {
                            view.performAppFeedback(appFeedback, HapticFeedbackConstants.CLOCK_TICK)
                            navController.navigate(item.route) {
                                popUpTo(navController.graph.startDestinationId) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    },
                    icon = {
                        Icon(
                            imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                            contentDescription = item.label,
                            modifier = Modifier.scale(scale)
                        )
                    },
                    label = { 
                        Text(
                            item.label,
                            maxLines = 1,
                            softWrap = false  // FIX: Prevent text wrapping
                        ) 
                    },
                    alwaysShowLabel = true,
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.primary,
                        selectedTextColor = MaterialTheme.colorScheme.primary,
                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        indicatorColor = MaterialTheme.colorScheme.primaryContainer
                    ),
                    interactionSource = interactionSource
                )
            }
        }
    }
}
