package com.jjemsboys.socialscience.studyapp.util

import android.content.Context
import android.media.MediaPlayer
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.HapticFeedbackConstants
import android.view.View
import androidx.core.content.getSystemService
import com.jjemsboys.socialscience.studyapp.R

object AppFeedbackManager {
    @Volatile private var hapticEnabled: Boolean = false
    @Volatile private var soundEnabled: Boolean = false

    fun init(context: Context) {
        // Warm up the app context if needed. No-op for now, but kept so the
        // call site remains stable and future feedback resources can be preloaded.
        context.applicationContext
    }

    fun updateSettings(hapticEnabled: Boolean, soundEnabled: Boolean) {
        this.hapticEnabled = hapticEnabled
        this.soundEnabled = soundEnabled
    }

    fun perform(view: View, feedbackConstant: Int = HapticFeedbackConstants.CONFIRM) {
        val context = view.context.applicationContext

        if (hapticEnabled) {
            val handled = view.performHapticFeedback(feedbackConstant)
            if (!handled) {
                vibrateFallback(context)
            }
        }

        if (soundEnabled) {
            playClick(context)
        }
    }

    private fun vibrateFallback(context: Context) {
        try {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val manager = context.getSystemService<VibratorManager>()
                manager?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                context.getSystemService<Vibrator>()
            } ?: return

            if (!vibrator.hasVibrator()) return

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createOneShot(18, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(18)
            }
        } catch (_: SecurityException) {
            // If the device blocks vibration, fail silently.
        }
    }

    private fun playClick(context: Context) {
        runCatching {
            MediaPlayer.create(context, R.raw.feedback_click)?.apply {
                setOnCompletionListener { player ->
                    player.release()
                }
                start()
            }
        }
    }
}
