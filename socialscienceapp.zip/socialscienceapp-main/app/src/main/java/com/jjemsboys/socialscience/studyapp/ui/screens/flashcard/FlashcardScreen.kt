@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.jjemsboys.socialscience.studyapp.ui.screens.flashcard

import android.view.HapticFeedbackConstants
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.jjemsboys.socialscience.studyapp.data.ChapterRepository
import com.jjemsboys.socialscience.studyapp.ui.components.PremiumButton
import com.jjemsboys.socialscience.studyapp.ui.components.AppProgressIndicator
import com.jjemsboys.socialscience.studyapp.ui.components.PremiumOutlinedButton
import com.jjemsboys.socialscience.studyapp.ui.viewmodel.FlashcardViewModel
import com.jjemsboys.socialscience.studyapp.ui.components.performAppFeedback

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FlashcardScreen(nav: NavController, chapterId: String) {
    val view = LocalView.current
    val viewModel: FlashcardViewModel = viewModel()

    LaunchedEffect(chapterId) {
        viewModel.setupFlashcards(chapterId, ChapterRepository.chapters)
    }

    if (viewModel.cards.isEmpty()) {
        EmptyFlashcardState(nav)
        return
    }

    if (viewModel.isFinished) {
        FlashcardResultScreen(nav, viewModel)
        return
    }

    val card = viewModel.cards[viewModel.currentIndex]

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Flashcards", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, null)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(horizontal = 16.dp)
                .fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            // Progress
            AppProgressIndicator(
                progress = { viewModel.progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp)),
                color = MaterialTheme.colorScheme.primary,
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )
            Text(
                text = "${viewModel.currentIndex + 1} / ${viewModel.cards.size}",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 8.dp)
            )

            Spacer(modifier = Modifier.height(32.dp))

            // Flip Card
            FlipCard(
                front = {
                    Text(
                        text = card.q,
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(24.dp)
                    )
                },
                back = {
                    Text(
                        text = card.a,
                        style = MaterialTheme.typography.bodyLarge,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(24.dp)
                    )
                },
                isFlipped = viewModel.isFlipped,
                onClick = {
                    view.performAppFeedback(HapticFeedbackConstants.CONFIRM)
                    viewModel.flip()
                }
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Tap card to flip",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.weight(1f))

            // Controls
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                PremiumButton(
                    onClick = {
                        view.performAppFeedback(HapticFeedbackConstants.REJECT)
                        viewModel.markUnknown()
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Close, null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Don't Know")
                }
                PremiumButton(
                    onClick = {
                        view.performAppFeedback(HapticFeedbackConstants.CONFIRM)
                        viewModel.markKnown()
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Check, null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Know It")
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
fun FlipCard(
    front: @Composable () -> Unit,
    back: @Composable () -> Unit,
    isFlipped: Boolean,
    onClick: () -> Unit
) {
    val rotation by animateFloatAsState(
        targetValue = if (isFlipped) 180f else 0f,
        animationSpec = tween(500, easing = FastOutSlowInEasing),
        label = "flip"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(360.dp)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    rotationY = rotation
                    cameraDistance = 12f * density
                }
                .clip(RoundedCornerShape(28.dp))
                .background(
                    if (rotation <= 90f) MaterialTheme.colorScheme.surface
                    else MaterialTheme.colorScheme.primaryContainer
                ),
            contentAlignment = Alignment.Center
        ) {
            if (rotation <= 90f) {
                front()
            } else {
                Box(
                    modifier = Modifier.graphicsLayer { rotationY = 180f }
                ) {
                    back()
                }
            }
        }
    }
}

@Composable
fun FlashcardResultScreen(nav: NavController, viewModel: FlashcardViewModel) {
    val view = LocalView.current

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(32.dp)
                .fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                "Session Complete!",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(32.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                ResultStat(
                    value = viewModel.knownCount,
                    label = "Known",
                    color = MaterialTheme.colorScheme.primary
                )
                ResultStat(
                    value = viewModel.unknownCount,
                    label = "Study Again",
                    color = MaterialTheme.colorScheme.error
                )
            }

            Spacer(modifier = Modifier.height(32.dp))

            PremiumButton(
                onClick = {
                    view.performAppFeedback(HapticFeedbackConstants.CONFIRM)
                    nav.popBackStack()
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Done", fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(12.dp))

            PremiumOutlinedButton(
                onClick = {
                    viewModel.setupFlashcards("all", ChapterRepository.chapters)
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Refresh, null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Restart", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun ResultStat(value: Int, label: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = value.toString(),
            style = MaterialTheme.typography.displaySmall,
            color = color,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = label,
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun EmptyFlashcardState(nav: NavController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("No flashcards available", style = MaterialTheme.typography.headlineSmall)
        Spacer(modifier = Modifier.height(16.dp))
        PremiumButton(onClick = { nav.popBackStack() }) {
            Text("Go Back")
        }
    }
}